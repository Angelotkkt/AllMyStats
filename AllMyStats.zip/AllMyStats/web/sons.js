// ================= Petits sons d'AllMyStats =================
// Tous synthétisés ici (Web Audio) : aucun fichier son, rien de copié. Courts et discrets.
// Réglages dans Paramètres > Sons (gardés dans cette fenêtre).

const SONS = (() => {
  let ctx = null, dernier = 0;
  const lire = (cle, defaut) => { try { const v = localStorage.getItem(cle); return v === null ? defaut : v; } catch (e) { return defaut; } };
  const ecrire = (cle, v) => { try { localStorage.setItem(cle, v); } catch (e) {} };
  const reglages = {
    get actifs() { return lire("sons_actifs", "1") === "1"; },
    set actifs(v) { ecrire("sons_actifs", v ? "1" : "0"); },
    get volume() { return Math.min(1, Math.max(0, Number(lire("sons_volume", "0.5")) || 0)); },
    set volume(v) { ecrire("sons_volume", String(v)); },
  };

  function audio() {
    if (!ctx) {
      const C = window.AudioContext || window.webkitAudioContext;
      if (!C) return null;
      ctx = new C();
    }
    if (ctx.state === "suspended") ctx.resume().catch(() => {});
    return ctx;
  }

  // Une note : forme d'onde, fréquence de départ -> d'arrivée, durée, volume relatif, décalage
  function note(a, sortie, { type = "sine", f1, f2 = f1, duree = 0.08, vol = 1, debut = 0 }) {
    const t = a.currentTime + debut;
    const o = a.createOscillator(), g = a.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f1, t);
    if (f2 !== f1) o.frequency.exponentialRampToValueAtTime(f2, t + duree);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + duree);
    o.connect(g).connect(sortie);
    o.start(t);
    o.stop(t + duree + 0.02);
  }

  function souffle(a, sortie, { duree = 0.14, vol = 0.5, de = 500, a_ = 2400, debut = 0 }) {
    const t = a.currentTime + debut;
    const n = Math.floor(a.sampleRate * duree);
    const tampon = a.createBuffer(1, n, a.sampleRate);
    const d = tampon.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
    const src = a.createBufferSource(), filtre = a.createBiquadFilter(), g = a.createGain();
    src.buffer = tampon;
    filtre.type = "bandpass"; filtre.Q.value = 1.4;
    filtre.frequency.setValueAtTime(de, t);
    filtre.frequency.exponentialRampToValueAtTime(a_, t + duree);
    g.gain.setValueAtTime(vol, t);
    src.connect(filtre).connect(g).connect(sortie);
    src.start(t);
  }

  const RECETTES = {
    clic: (a, s) => note(a, s, { type: "sine", f1: 1250, f2: 820, duree: 0.045, vol: 0.35 }),
    onglet: (a, s) => { note(a, s, { type: "triangle", f1: 520, duree: 0.06, vol: 0.4 });
      note(a, s, { type: "triangle", f1: 780, duree: 0.08, vol: 0.35, debut: 0.05 }); },
    succes: (a, s) => [523, 659, 784, 1047].forEach((f, i) =>
      note(a, s, { type: "triangle", f1: f, duree: 0.16, vol: 0.32, debut: i * 0.06 })),
    erreur: (a, s) => { note(a, s, { type: "sawtooth", f1: 240, f2: 200, duree: 0.12, vol: 0.12 });
      note(a, s, { type: "sawtooth", f1: 180, f2: 140, duree: 0.18, vol: 0.12, debut: 0.11 }); },
    info: (a, s) => { note(a, s, { type: "sine", f1: 1320, duree: 0.35, vol: 0.22 });
      note(a, s, { type: "sine", f1: 1980, duree: 0.25, vol: 0.08 }); },
    ouvrir: (a, s) => souffle(a, s, { duree: 0.13, vol: 0.35, de: 400, a_: 2600 }),
    fermer: (a, s) => souffle(a, s, { duree: 0.11, vol: 0.3, de: 2400, a_: 450 }),
    bascule: (a, s) => note(a, s, { type: "square", f1: 660, f2: 990, duree: 0.05, vol: 0.08 }),
    maj: (a, s) => [784, 988, 1175].forEach((f, i) =>
      note(a, s, { type: "sine", f1: f, duree: 0.3, vol: 0.25, debut: i * 0.09 })),
  };

  function jouer(nom, forcer = false) {
    if (!forcer && !reglages.actifs) return;
    const recette = RECETTES[nom];
    if (!recette) return;
    const maintenant = performance.now();
    if (!forcer && maintenant - dernier < 45) return;   // jamais deux sons collés
    dernier = maintenant;
    const a = audio();
    if (!a) return;
    const sortie = a.createGain();
    sortie.gain.value = reglages.volume * 0.9;
    sortie.connect(a.destination);
    try { recette(a, sortie); } catch (e) { /* pas de son, pas grave */ }
  }

  return { jouer, reglages, noms: Object.keys(RECETTES) };
})();

const son = (nom) => SONS.jouer(nom);

// Clics : un petit « tic » sur les boutons, un son d'onglet sur la barre de gauche et les onglets
document.addEventListener("click", (e) => {
  const cible = e.target.closest("button, [role=tab], summary, .interrupteur input, a.bouton-lien");
  if (!cible || cible.disabled || cible.dataset.son === "aucun") return;
  if (cible.matches(".interrupteur input")) return son("bascule");
  if (cible.closest("nav") || cible.matches("[role=tab], .onglet")) return son("onglet");
  son("clic");
}, true);

// Fenêtres (Paramètres, tests…) : un petit souffle à l'ouverture et à la fermeture
(() => {
  const ouvrir = HTMLDialogElement.prototype.showModal;
  HTMLDialogElement.prototype.showModal = function () {
    son("ouvrir");
    if (!this._sonFermer) {
      this._sonFermer = true;
      this.addEventListener("close", () => son("fermer"));
    }
    return ouvrir.call(this);
  };
})();
