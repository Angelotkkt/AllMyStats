"""Lance AllMyStats.

Ce fichier est le seul qui est « figé » dans AllMyStats.exe. Tout le reste du programme
(dossiers core, jeux, web) est copié dans %APPDATA%\\AllMyStats\\app et chargé de là :
c'est ce qui permet de mettre à jour AllMyStats sans refaire le .exe.

Options :
  --arriere-plan     tourne sans fenêtre (démarrage avec Windows)
  --relance          redémarrage après une mise à jour (n'ouvre pas de nouvelle fenêtre)
  --appli            (version .py) teste le mode « appli » comme le .exe
  --sans-navigateur  (version .py) n'ouvre pas le navigateur
"""

import importlib
import os
import re
import shutil
import sys
import traceback

FIGE = getattr(sys, "frozen", False)
ICI = getattr(sys, "_MEIPASS", None) if FIGE else os.path.dirname(os.path.abspath(__file__))
INCLUS = os.path.join(ICI, "app") if FIGE else ICI  # le code livré avec le programme

if FIGE:
    DONNEES = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "AllMyStats")
    ANCIEN = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "MesStats")
    if not os.path.exists(DONNEES) and os.path.isdir(ANCIEN):
        # AllMyStats s'appelait MesStats : on reprend tes stats et tes connexions
        try:
            shutil.copytree(ANCIEN, DONNEES, ignore=shutil.ignore_patterns("app", "app_*", "journal.txt"))
        except OSError:
            pass
else:
    DONNEES = os.path.join(ICI, "data")
os.makedirs(DONNEES, exist_ok=True)
os.environ["MESSTATS_DONNEES"] = DONNEES
APP = os.path.join(DONNEES, "app")  # le code installé (mis à jour)

if FIGE:
    # Pas de console dans le .exe : les messages vont dans un journal
    journal = open(os.path.join(DONNEES, "journal.txt"), "w", encoding="utf-8", buffering=1)
    sys.stdout = sys.stderr = journal
else:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

if sys.version_info < (3, 8):
    sys.exit("Il faut Python 3.8 ou plus récent : https://www.python.org/downloads/")


def version_de(dossier):
    try:
        with open(os.path.join(dossier, "core", "version.py"), encoding="utf-8") as f:
            m = re.search(r'VERSION\s*=\s*"([\d.]+)"', f.read())
        return tuple(int(x) for x in m.group(1).split(".")) if m else None
    except (OSError, ValueError):
        return None


def code_valide(dossier):
    return all(os.path.exists(os.path.join(dossier, *p))
               for p in (("core", "serveur.py"), ("jeux", "__init__.py"), ("web", "index.html")))


def installer_le_code_inclus():
    """Copie le code livré dans le .exe vers %APPDATA%\\AllMyStats\\app."""
    temp = APP + "_copie"
    shutil.rmtree(temp, ignore_errors=True)
    for nom in ("core", "jeux", "web"):
        shutil.copytree(os.path.join(INCLUS, nom), os.path.join(temp, nom),
                        ignore=shutil.ignore_patterns("__pycache__"))
    shutil.rmtree(APP, ignore_errors=True)
    os.replace(temp, APP)


def choisir_le_code():
    v_inclus, v_app = version_de(INCLUS), version_de(APP)
    if code_valide(APP) and v_app and (not v_inclus or v_app >= v_inclus):
        return APP  # une version installée (peut-être plus récente que le .exe)
    if FIGE:
        installer_le_code_inclus()
        return APP
    return INCLUS


def demarrer(code):
    sys.path.insert(0, code)
    serveur = importlib.import_module("core.serveur")
    serveur.demarrer(
        port=8765,
        ouvrir_navigateur="--sans-navigateur" not in sys.argv and "--relance" not in sys.argv,
        mode_appli=FIGE or "--appli" in sys.argv or "--relance" in sys.argv,
        arriere_plan="--arriere-plan" in sys.argv,
    )


if __name__ == "__main__":
    code = choisir_le_code()
    try:
        demarrer(code)
    except Exception:
        traceback.print_exc()
        # Une mise à jour cassée ? On revient à la version précédente, sinon à celle du .exe.
        ancien = APP + "_ancien"
        if code == APP and code_valide(ancien):
            print("[!] La nouvelle version ne démarre pas : retour à la version précédente.")
            shutil.rmtree(APP, ignore_errors=True)
            os.replace(ancien, APP)
        elif code == APP and FIGE:
            print("[!] Retour à la version incluse dans AllMyStats.exe.")
            installer_le_code_inclus()
        else:
            raise
        for nom in [n for n in sys.modules if n == "core" or n.startswith(("core.", "jeux"))]:
            del sys.modules[nom]
        sys.path.remove(code)
        demarrer(APP)
