# AllMyStats (AMS)

Tes jeux, tes stats : toutes tes progressions de jeu au même endroit, sur ton PC.

> AllMyStats s'appelait avant **MesStats**. Si tu l'avais déjà, refais le .exe avec creer_exe.bat :
> tes stats et tes connexions sont reprises toutes seules, et tu peux supprimer l'ancien MesStats.exe.

## Créer l'application (AllMyStats.exe) : UNE SEULE FOIS

1. Il faut **Python 3.8 ou plus récent**, seulement pour fabriquer le .exe : https://www.python.org/downloads/
   (pendant l'installation, coche bien **« Add Python to PATH »**).
2. Double-clique sur **creer_exe.bat** et attends 1 à 2 minutes.
3. **AllMyStats.exe** apparaît dans le dossier. Mets-le sur ton Bureau ou épingle-le à la barre des tâches.

L'appli s'ouvre dans sa propre fenêtre. Une fois le .exe créé, Python n'est plus nécessaire.

> Si Windows Defender bloque le .exe (ça arrive avec les programmes faits maison),
> clique sur « Informations complémentaires » puis « Exécuter quand même ».

## Mettre à jour AllMyStats (sans rien télécharger)

AllMyStats vérifie tout seul sur Internet toutes les 6 heures s'il existe une nouvelle version,
puis la télécharge. Elle s'installe quand sa fenêtre est fermée (ou au prochain démarrage),
sans rien désinstaller ni refaire le .exe. Tes stats et tes connexions sont gardées.

- Paramètres > Mises à jour > **Vérifier maintenant** pour ne pas attendre.
- Décoche **Installer les mises à jour toutes seules** si tu préfères cliquer sur le bandeau.
- La source des mises à jour (un dépôt GitHub public, ex : `pseudo/AllMyStats`) se règle dans
  Paramètres > Mises à jour > Source des mises à jour.
- Toujours possible : poser un AllMyStats.zip dans tes Téléchargements, AllMyStats le repère.
- Si une version ne démarre pas, AllMyStats revient tout seul à la précédente.

## Tout automatique : le mode « Toujours actif »

Dans **AllMyStats**, coche **« Démarrer avec Windows et tourner en arrière-plan »**.
AllMyStats tourne alors en silence (sans fenêtre), même quand tu le fermes :
- il actualise tous tes jeux toutes les 30 minutes ;
- il mesure ton **temps de jeu Genshin** dès que le jeu est lancé ;
- il **lit ton écran Blox Fruits** pendant que tu joues (niveau, Beli, fragments, prime).
Double-clique sur AllMyStats.exe pour ouvrir la fenêtre quand tu veux voir tes stats.
Pour l'arrêter complètement : AllMyStats > « Arrêter complètement AllMyStats ».

## Genshin Impact : tout est automatique

AllMyStats s'actualise tout seul à l'ouverture, puis toutes les 20 minutes tant que l'appli est ouverte.
Les petites pastilles en haut de la page indiquent si chaque source marche () ou a un souci (!).

1. **Profil** (juste avec ton UID, dans Réglages) : niveau d'aventure, niveau du monde, succès, Abysse,
   Théâtre, amitié, et les persos de ta vitrine.
   Pour voir leurs armes et leurs stats : en jeu, Profil > Modifier la vitrine > « Afficher les détails des personnages ».
2. **HoYoLAB** : clique sur **Se connecter avec HoYoLAB**. Une fenêtre s'ouvre : connecte-toi avec ton compte
   HoYoverse (le même que dans le jeu). C'est tout : AllMyStats trouve ton UID, active tes notes en temps réel
   et récupère jours actifs, tous tes persos, exploration, coffres, oculi, résine, commissions, primos et mora.
   - Ton mot de passe ne passe jamais par AllMyStats : tu le tapes sur le vrai site de HoYoLAB.
   - La fenêtre garde ta connexion : la prochaine fois, un clic suffit.
   - Les cookies sont rangés dans config.json (comme un mot de passe : ne partage pas ce fichier).
3. **Vœux** : ouvre l'historique des vœux dans le jeu (sur ce PC). AllMyStats trouve le lien tout seul et
   récupère tous tes vœux : total, 5, 4, pity de chaque bannière, tes derniers 5.
   Le lien expire au bout de 24 h : rouvre l'historique en jeu de temps en temps.
   Tes vœux sont gardés pour toujours (le jeu, lui, n'en garde qu'un an).

4. **Temps de jeu** : mesuré tout seul quand Genshin est lancé sur ce PC (avec le mode « Toujours actif »).

Ce que personne ne peut récupérer : le nombre de primogemmes et de destins que tu as *en ce moment*
(le jeu ne les donne à aucun site). AllMyStats montre à la place les primos gagnées (journal du voyageur)
et dépensées (vœux).

## Blox Fruits (Roblox)

Clique sur **Se connecter avec Roblox**. Une fenêtre roblox.com s'ouvre : connecte-toi normalement. C'est tout.

Automatique :
- ton **profil Roblox** et le nombre de joueurs connectés au jeu ;
- tes **badges Blox Fruits** (obtenus, à débloquer, et la date où tu les as eus), même si ton inventaire est privé ;
- tes **game pass** Blox Fruits ;
- **en ce moment** : si tu joues (et dans quelle mer) et **tes amis qui jouent à Blox Fruits** ;
- ton **temps de jeu**, tes parties et la **mer la plus loin** atteinte : AllMyStats lit les journaux que Roblox
  écrit sur ce PC (`%LOCALAPPDATA%\Roblox\logs`). Roblox efface les vieux journaux, donc le temps est compté
  à partir d'aujourd'hui (plus les derniers jours encore présents), puis gardé pour toujours.

Ta connexion Roblox reste dans la fenêtre de connexion (comme dans un navigateur) : AllMyStats ne l'écrit dans aucun
de ses fichiers et ne voit jamais ton mot de passe. Pour te déconnecter, supprime le dossier
`%APPDATA%\AllMyStats\connexion_roblox`.

**Niveau, Beli, fragments et prime** : Blox Fruits ne les donne à personne, même avec ton compte connecté.
Alors AllMyStats les **lit sur ton écran** pendant que tu joues : toutes les minutes, si la fenêtre Roblox est
au premier plan et que tu es dans Blox Fruits, il prend une capture, lit le texte avec la reconnaissance de
texte de Windows, puis efface la capture. Ça ne touche pas au jeu.
- La prime n'est lue que quand elle est affichée à l'écran.
- Si une valeur est fausse, corrige-la en bas de la page (« Noter ou corriger une stat »).
- La maîtrise du fruit reste à noter à la main.

Sans connexion, AllMyStats marche quand même avec juste ton pseudo (badges publics seulement).

## Call of Duty

Dans la barre de gauche, le dossier **Call of Duty** contient : Black Ops 6, Black Ops 7, Cold War, MW4,
Warzone, Warzone MW4, MW3 (2023) et MW2 (2022). Les 8 jeux partagent la même connexion et les mêmes réglages.

Activision ne partage plus les stats des jeux récents. AllMyStats utilise donc trois sources :
1. **Ton Combat Record, lu sur l'écran** (tous les jeux) : en jeu, ouvre Carrière (ou Profil) > Combat Record
   et attends quelques secondes. AllMyStats le lit avec la reconnaissance de texte de Windows et range les
   stats dans le bon jeu : K/D, éliminations, morts, victoires, défaites, précision, score/min, temps de jeu,
   et aussi les onglets Zombies (manche max, zombies éliminés) et Warzone (victoires, top 5, top 10).
   La capture est effacée tout de suite.
2. **Ton compte Activision** (Se connecter avec Activision) : stats officielles de **Cold War** et **MW2**,
   les seuls jeux qu'Activision partage encore. Ta connexion reste dans la fenêtre de connexion.
3. **Le temps de jeu**, mesuré quand Call of Duty est lancé sur ce PC.

Warzone : ce que tu joues depuis le 6 novembre 2026 (Saison 1 de MW4) va dans **Warzone MW4**,
avant dans **Warzone**.

Pour que la lecture d'écran marche même fenêtre fermée, active **Toujours actif** dans les Paramètres.
Si une valeur est mal lue, corrige-la en bas de la page du jeu.

## La lecture d'écran ne marche pas ?

Sur la page de Blox Fruits ou d'un Call of Duty, clique sur **Tester la lecture d'écran**.
Pendant le compte à rebours de 8 secondes, va sur le jeu (clique dans sa fenêtre ou Alt + Tab).
Un petit son signale la capture : reviens sur AllMyStats, il te montre chaque étape
(jeu lancé, jeu au premier plan, capture, lecture du texte, stats reconnues) et ce qui bloque.
Les stats trouvées pendant le test sont enregistrées tout de suite.

Les causes les plus courantes :
- le jeu n'était pas la fenêtre au premier plan ;
- le jeu est en **plein écran exclusif** : la capture est noire. Choisis « Plein écran fenêtré » (ou « Sans bordure ») ;
- l'écran du jeu ne montre pas les chiffres (menu ouvert par-dessus, Combat Record fermé).

## Le logo et les emojis

Tout est dessiné pour AllMyStats : le logo AMS, les emojis des jeux (primogemme, vœu, Beli, fragments,
insignes Call of Duty…)
et ceux de l'interface (réglages, actualiser, connexion, alertes…). Ils sont dans `web/icones.js`.
Tu peux en ajouter ou les modifier : chaque emoji est un dessin SVG de 32 × 32.

## Ajouter un autre jeu

1. Copie `jeux/_modele_nouveau_jeu.py` et renomme la copie sans le `_` (ex : `jeux/fortnite.py`).
2. Change le nom et la liste des stats dans le fichier.
3. Relance **creer_exe.bat** pour refaire le .exe avec le nouveau jeu. Tes stats sont conservées.

Pour tester une modif sans refaire le .exe : double-clique sur **lancer.bat** (ouvre l'appli dans le navigateur).

## Où sont mes données ?

Dans `%APPDATA%\AllMyStats` (colle ça dans la barre d'adresse de l'Explorateur) :
- `stats.db` : tout ton historique (garde-le si tu changes de PC)
- `config.json` : tes réglages (UID…)
- `journal.txt` : messages du programme, utile en cas de problème

Avec lancer.bat, les données sont dans le dossier `data` du projet.
Si ce dossier existe déjà quand tu lances le .exe pour la première fois, ses données sont reprises.
