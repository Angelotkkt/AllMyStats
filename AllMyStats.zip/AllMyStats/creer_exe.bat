@echo off
title Creation de AllMyStats.exe
cd /d "%~dp0"

echo.
echo  ==========================================
echo    Fabrication de l'application AllMyStats
echo  ==========================================
echo.
echo  A faire UNE SEULE FOIS : les prochaines versions s'installeront
echo  directement depuis AllMyStats (Parametres, Mises a jour).
echo  Si tu avais MesStats.exe, tu peux le supprimer : tes stats sont reprises.
echo.

rem ---- Trouver Python ----
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY goto pas_python
%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)" >nul 2>nul
if errorlevel 1 goto pas_python

rem ---- Fermer AllMyStats s'il est ouvert (sinon le .exe ne peut pas etre remplace) ----
taskkill /im AllMyStats.exe /f >nul 2>nul
taskkill /im MesStats.exe /f >nul 2>nul

echo  [1/3] Installation de PyInstaller (fabrique le .exe) et pywebview (la fenetre de l'appli)...
%PY% -m pip install --upgrade --disable-pip-version-check pyinstaller pywebview
if errorlevel 1 goto erreur

echo.
echo  [2/3] Fabrication de AllMyStats.exe, ca prend 1 a 2 minutes...
rem Le code (core, jeux, web) est range a part dans le .exe pour pouvoir etre mis a jour.
rem Les --hidden-import emballent les morceaux de Python dont les futures versions pourraient avoir besoin.
%PY% -m PyInstaller --noconfirm --clean --onefile --windowed --name AllMyStats ^
  --icon "%~dp0web\icone.ico" ^
  --add-data "%~dp0core;app/core" ^
  --add-data "%~dp0jeux;app/jeux" ^
  --add-data "%~dp0web;app/web" ^
  --collect-all webview --collect-all clr_loader --collect-all pythonnet --hidden-import clr ^
  --collect-submodules http --collect-submodules urllib --collect-submodules json ^
  --collect-submodules email --collect-submodules xml --collect-submodules concurrent ^
  --collect-submodules sqlite3 --collect-submodules importlib --collect-submodules ctypes ^
  --hidden-import mimetypes --hidden-import webbrowser --hidden-import socketserver ^
  --hidden-import glob --hidden-import hashlib --hidden-import hmac --hidden-import random ^
  --hidden-import string --hidden-import base64 --hidden-import struct --hidden-import socket ^
  --hidden-import ssl --hidden-import subprocess --hidden-import zipfile --hidden-import io ^
  --hidden-import pkgutil --hidden-import inspect --hidden-import tempfile --hidden-import winreg ^
  --hidden-import csv --hidden-import statistics --hidden-import math --hidden-import uuid ^
  --hidden-import secrets --hidden-import gzip --hidden-import zlib --hidden-import queue ^
  --hidden-import locale --hidden-import calendar --hidden-import platform --hidden-import unicodedata ^
  --hidden-import difflib --hidden-import textwrap --hidden-import fnmatch --hidden-import html ^
  --hidden-import decimal --hidden-import fractions --hidden-import dataclasses --hidden-import pathlib ^
  --hidden-import logging --hidden-import bisect --hidden-import heapq --hidden-import pprint ^
  --distpath "%~dp0." --workpath "%~dp0build" --specpath "%~dp0build" ^
  "%~dp0lancer.py"
if errorlevel 1 goto erreur

echo.
echo  [3/3] Nettoyage...
rmdir /s /q "%~dp0build" 2>nul

echo.
echo  ==========================================
echo    C'est pret ! AllMyStats.exe est dans ce dossier.
echo    Tu peux le mettre sur ton Bureau ou l'epingler
echo    a la barre des taches.
echo  ==========================================
echo.
explorer /select,"%~dp0AllMyStats.exe"
pause
exit /b 0

:pas_python
echo  Python n'est pas installe sur ce PC, il en faut pour fabriquer le .exe.
echo  Une fois le .exe cree, Python ne sera plus necessaire.
echo.
echo  1. Installe Python depuis la page qui va s'ouvrir.
echo  2. Pendant l'installation, coche bien "Add Python to PATH".
echo  3. Relance creer_exe.bat.
start "" https://www.python.org/downloads/
pause
exit /b 1

:erreur
echo.
echo  Oups, la fabrication a echoue.
echo  Fais une capture de cette fenetre et montre-la a Claude.
pause
exit /b 1
