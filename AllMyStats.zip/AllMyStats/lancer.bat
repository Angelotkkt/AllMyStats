@echo off
chcp 65001 >nul
title AllMyStats
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 lancer.py
) else (
    python lancer.py
)
pause
