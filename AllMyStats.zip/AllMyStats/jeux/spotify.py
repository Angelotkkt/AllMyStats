"""Catégorie « Spotify » : le lecteur web de Spotify affiché dans AllMyStats, comme la carte officielle
de Genshin. C'est une vraie fenêtre de navigateur collée sur la page : tu t'y connectes une fois avec ton
compte Spotify, comme sur le site, et la connexion reste dans cette fenêtre (AllMyStats ne la voit pas).

Quand tu changes de catégorie, la fenêtre est seulement cachée : la musique continue."""

from ._pages import PageEnLigne


class Spotify(PageEnLigne):
    id = "spotify"
    nom = "Spotify"
    icone = "jeu_spotify"
    couleur = "#2BD97C"
    texte_connexion = "Spotify ouvert dans sa fenêtre : connecte-toi une fois, ce sera gardé"
    note_page = ("Connecte-toi directement dans Spotify (en haut à droite), comme sur le site. "
                 "Tu peux changer de catégorie : la musique continue.")
    cartes_en_ligne = [
        {"id": "lecteur", "nom": "Lecteur", "url": "https://open.spotify.com/", "icone": "musique",
         "aide": "Le lecteur web de Spotify : tes playlists, ta bibliothèque, la recherche.",
         "collee": True, "garder": True},
    ]

    def en_dict(self):
        return {**super().en_dict(), "note_page": self.note_page,
                "texte_attente": "Ouverture de Spotify…", "texte_affiche": "Spotify est affiché ici."}
