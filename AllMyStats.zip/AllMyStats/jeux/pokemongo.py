"""Pokémon GO.

Pokémon GO se joue sur téléphone et n'a pas d'API publique : AllMyStats lit tes CAPTURES D'ÉCRAN
de ton profil de dresseur (avec l'OCR de Windows) :
  - automatiquement : les nouvelles captures qui arrivent sur ce PC (OneDrive, dossier Captures d'écran,
    ou le dossier choisi dans les Réglages) sont lues toutes les minutes ;
  - ou à la main : glisse tes captures dans AllMyStats.
On ne garde que les chiffres trouvés (niveau, PX, distance, Pokémon attrapés, PokéStops) :
les images ne sont jamais copiées ni modifiées.
"""

import json
import os
import re
import threading
import time
import unicodedata
from datetime import datetime

from core import windows

from .base import ErreurJeu, Jeu, Stat

EXTENSIONS = (".png", ".jpg", ".jpeg", ".bmp")
NIVEAU_MAX = 80
PAR_MINUTE = 4                # captures lues au plus par minute (l'OCR prend quelques secondes)
PREMIERE_FOIS = 14 * 86400    # au premier lancement, on regarde les captures des 14 derniers jours
_VERROU = threading.Lock()
MOTS_CAPTURE = re.compile(r"screenshot|capture|screen|pok|pogo", re.I)   # + tous les .png (captures iPhone)

# (clé, libellé sans accents en minuscules) — la valeur est sur la même ligne ou juste en dessous
LIBELLES = [
    ("xp", r"total\s*(de\s*)?(xp|px)|(xp|px)\s*tota(l|ux|les?)|points?\s*d.?experience\s*tota"),
    ("distance", r"distance(\s*(parcourue|marchee|totale|walked))?"),
    ("attrapes", r"pokemons?\s*(attrapes?|captures?|caught)"),
    ("pokestops", r"poke\s*stops?\s*(visites?|visited)"),
]
NOMBRE = r"\d{1,3}(?:[   .,]\d{3})+|\d+"
KM = re.compile(rf"({NOMBRE})(?:[.,](\d{{1,2}}))?\s*km\b", re.I)


def _sans_accents(texte):
    return "".join(c for c in unicodedata.normalize("NFD", texte) if unicodedata.category(c) != "Mn").lower()


def _entier(texte):
    m = re.search(NOMBRE, texte or "")
    return int(re.sub(r"\D", "", m.group(0))) if m else None


def _km(texte):
    m = KM.search(texte or "")
    if not m:
        return None
    return round(int(re.sub(r"\D", "", m.group(1))) + (int(m.group(2)) / 10 ** len(m.group(2)) if m.group(2) else 0), 1)


def lire_profil(lignes):
    """Trouve les stats du profil de dresseur dans le texte d'une capture. Renvoie {clé: valeur} (au moins 2)."""
    lignes = [l.strip() for l in lignes if l.strip()]
    bas = [_sans_accents(l) for l in lignes]
    trouve = {}

    for i, ligne in enumerate(bas):
        for cle, motif in LIBELLES:
            m = re.search(motif, ligne)
            if not m:
                continue
            # La valeur : après le libellé, sinon sur les 2 lignes suivantes
            morceaux = [lignes[i][m.end():]] + lignes[i + 1:i + 3]
            for morceau in morceaux:
                valeur = _km(morceau) if cle == "distance" else _entier(morceau)
                if valeur is not None:
                    trouve.setdefault(cle, []).append(valeur)
                    break
            break

    # Niveau : « Niv. 42 », « Niveau 42 », « Level 42 », ou « NIVEAU » puis « 42 » en dessous
    for i, ligne in enumerate(bas):
        m = re.search(r"\b(?:niv(?:eau)?|lv|lvl|level)\b\.?\s*(\d{1,2})\b", ligne)
        if not m and re.fullmatch(r"(niveau|level)", ligne) and i + 1 < len(bas) and re.fullmatch(r"\d{1,2}", bas[i + 1]):
            m = re.match(r"(\d+)", bas[i + 1])
        if m and 1 <= int(m.group(1)) <= NIVEAU_MAX:
            trouve.setdefault("niveau", []).append(int(m.group(1)))

    # Plusieurs valeurs (ex : distance de la semaine + distance totale) : on garde la plus grande
    valeurs = {cle: max(v) for cle, v in trouve.items()}
    return valeurs if len(valeurs) >= 2 else {}


def _lire(chemin, defaut):
    try:
        with open(chemin, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return defaut


def _ecrire(chemin, data):
    tmp = chemin + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    os.replace(tmp, chemin)


class PokemonGo(Jeu):
    id = "pokemongo"
    nom = "Pokémon GO"
    icone = ""
    couleur = "#3FB6E8"
    stat_vedette = "niveau"
    import_images = True
    consigne_import = ("Sur ton téléphone : Profil de dresseur (portrait en bas à gauche), descends jusqu'à tes stats "
                       "(PX, distance, Pokémon attrapés, PokéStops), puis fais une capture d'écran.")

    reglages = [
        {
            "cle": "dossier_captures",
            "nom": "Dossier de tes captures (facultatif)",
            "optionnel": True,
            "aide": "AllMyStats regarde déjà tout seul : Images > Captures d'écran, Images > Pellicule et "
                    "les mêmes dossiers dans OneDrive. Si tes captures du téléphone arrivent ailleurs sur ce PC, "
                    "colle ici le chemin du dossier.",
        },
    ]

    D = "Dresseur"
    stats = [
        Stat("niveau", "Niveau de dresseur", "auto", groupe=D, icone="pogo_niveau", modifiable=True,
             etiquette="capture", aide=f"Lu sur tes captures du profil (niveau max : {NIVEAU_MAX})"),
        Stat("xp", "PX totaux", "auto", groupe=D, icone="pogo_xp", modifiable=True, etiquette="capture"),
        Stat("distance", "Distance parcourue", "auto", unite="km", decimales=1, groupe=D, icone="pogo_distance",
             modifiable=True, etiquette="capture"),
        Stat("attrapes", "Pokémon attrapés", "auto", groupe=D, icone="pogo_attrapes", modifiable=True,
             etiquette="capture"),
        Stat("pokestops", "PokéStops visités", "auto", groupe=D, icone="pogo_pokestop", modifiable=True,
             etiquette="capture"),
    ]

    # ------------------------------------------------------------------ captures

    def _fichier_releves(self, dossier):
        return os.path.join(dossier, "pogo_releves.json")

    def _garder(self, valeurs, dossier, source):
        """Garde les valeurs lues. Une valeur ne peut pas baisser (sinon : vieille capture ou erreur de lecture)."""
        chemin = self._fichier_releves(dossier)
        releves = _lire(chemin, {"valeurs": {}, "captures": []})
        connues = releves["valeurs"]
        gardees = {k: v for k, v in valeurs.items() if v >= connues.get(k, 0)}
        connues.update(gardees)
        releves["captures"] = ([{"fichier": source, "quand": time.time(), "trouve": len(gardees)}]
                               + releves.get("captures", []))[:20]
        _ecrire(chemin, releves)
        return gardees

    def lire_capture(self, chemin, dossier, nom_affiche=None):
        """Lit une capture d'écran. Renvoie (valeurs gardées, lignes lues, message)."""
        r = windows.lire_image(chemin)
        if r["etat"] == "PAS_WINDOWS":
            raise ErreurJeu("La lecture des captures ne marche que sur Windows.")
        if r["etat"] != "OK":
            raise ErreurJeu(f"Windows n'a pas pu lire cette image ({r.get('message') or r['etat']}).")
        valeurs = lire_profil(r["lignes"])
        if not valeurs:
            return {}, r["lignes"], "Ce n'est pas une capture du profil de dresseur (aucune stat trouvée)."
        gardees = self._garder(valeurs, dossier, nom_affiche or os.path.basename(chemin))
        ignorees = len(valeurs) - len(gardees)
        message = f"{len(gardees)} stat(s) lue(s)"
        if ignorees:
            message += f" · {ignorees} ignorée(s) car plus basses que tes dernières valeurs (capture plus ancienne ?)"
        return gardees, r["lignes"], message

    def _dossiers(self, reglages):
        maison = os.path.expanduser("~")
        chemins = [(reglages.get("dossier_captures") or "").strip().strip('"')]
        for racine in ((), ("OneDrive",)):
            for images in ("Pictures", "Images"):
                for sous in ("Screenshots", "Captures d’écran", "Captures d'écran", "Camera Roll", "Pellicule",
                             "Samsung Gallery"):
                    chemins.append(os.path.join(maison, *racine, images, sous))
        vus, dossiers = set(), []
        for c in chemins:
            if c and os.path.isdir(c) and os.path.normcase(os.path.abspath(c)) not in vus:
                vus.add(os.path.normcase(os.path.abspath(c)))
                dossiers.append(c)
        return dossiers

    def _nouvelles_captures(self, reglages, etat):
        depuis = etat.setdefault("depuis", time.time() - PREMIERE_FOIS)
        vus = etat.setdefault("vus", {})
        perso = (reglages.get("dossier_captures") or "").strip().strip('"')
        candidats = []
        for dossier in self._dossiers(reglages):
            dans_perso = perso and os.path.normcase(os.path.abspath(dossier)) == os.path.normcase(os.path.abspath(perso))
            for racine, sous, fichiers in os.walk(dossier):
                if racine[len(dossier):].count(os.sep) >= 2:   # Pellicule\2026\11 : pas plus profond
                    sous[:] = []
                for f in fichiers:
                    if not f.lower().endswith(EXTENSIONS):
                        continue
                    # Hors de ton dossier perso, on ne lit que ce qui ressemble à une capture d'écran
                    if not dans_perso and not (MOTS_CAPTURE.search(f) or f.lower().endswith(".png")):
                        continue
                    chemin = os.path.join(racine, f)
                    try:
                        st = os.stat(chemin)
                    except OSError:
                        continue
                    if st.st_mtime <= depuis or st.st_size > 25_000_000 or vus.get(chemin) == st.st_mtime:
                        continue
                    candidats.append((st.st_mtime, chemin))
        return sorted(candidats)   # les plus anciennes d'abord : l'historique reste dans l'ordre

    def _scanner(self, reglages, dossier, maximum=PAR_MINUTE):
        if os.name != "nt":
            return {}, 0
        with _VERROU:
            return self._scanner_sans_verrou(reglages, dossier, maximum)

    def _scanner_sans_verrou(self, reglages, dossier, maximum):
        chemin_etat = os.path.join(dossier, "pogo_dossiers.json")
        etat = _lire(chemin_etat, {})
        valeurs, lues = {}, 0
        for mtime, chemin in self._nouvelles_captures(reglages, etat)[:maximum]:
            etat["vus"][chemin] = mtime
            lues += 1
            try:
                trouve, _, _ = self.lire_capture(chemin, dossier)
                valeurs.update(trouve)
            except ErreurJeu:
                pass
        if lues:
            # On oublie les fichiers trop anciens pour garder le fichier petit
            limite = time.time() - 30 * 86400
            etat["vus"] = {c: m for c, m in etat["vus"].items() if m > limite}
            _ecrire(chemin_etat, etat)
        elif "depuis" in etat and not os.path.exists(chemin_etat):
            _ecrire(chemin_etat, etat)
        return valeurs, lues

    def surveiller(self, reglages, dossier):
        valeurs, _ = self._scanner(reglages, dossier)
        return valeurs or None

    # ------------------------------------------------------------------ actualisation

    def recuperer(self, reglages, dossier):
        nouvelles, lues = self._scanner(reglages, dossier, maximum=20)
        releves = _lire(self._fichier_releves(dossier), {"valeurs": {}, "captures": []})
        valeurs = dict(releves["valeurs"])
        if lues:
            message = f"{lues} nouvelle(s) capture(s) lue(s)"
        elif valeurs:
            message = "Pas de nouvelle capture"
        else:
            message = "Aucune capture du profil lue pour l'instant"
        return valeurs, self.fiche(reglages, dossier), message

    def fiche(self, reglages, dossier):
        """La fiche affichée sous les stats (sources, conseils, dernières captures)."""
        releves = _lire(self._fichier_releves(dossier), {"valeurs": {}, "captures": []})

        dossiers = self._dossiers(reglages) if os.name == "nt" else []
        derniere = (releves.get("captures") or [None])[0]
        etat = [
            {"nom": "Captures du profil", "icone": "pogo_capture", "ok": True if derniere else None,
             "texte": (f"dernière lue le {datetime.fromtimestamp(derniere['quand']).strftime('%d/%m à %H:%M')}"
                       if derniere else "aucune lue pour l'instant")},
            {"nom": "Dossiers surveillés", "icone": "dossier_photos", "ok": True if dossiers else None,
             "texte": f"{len(dossiers)} dossier(s)" if dossiers else "aucun trouvé"},
        ]
        conseils = [
            ("pogo_capture", "Sur ton téléphone : **Profil de dresseur** (portrait en bas à gauche), descends jusqu'à "
                             "tes stats, puis fais une **capture d'écran**."),
            ("dossier_photos", "Pour que ce soit automatique : active la **sauvegarde des photos dans OneDrive** sur ton "
                               "téléphone (avec les captures d'écran). AllMyStats lit les nouvelles captures toutes les minutes."),
            ("ajouter", "Sinon, glisse tes captures dans le cadre « Importer des captures », plus haut sur cette page."),
        ]
        sections = [{"titre": "Comment ça marche", "icone": "astuce", "conseils": conseils}]
        if dossiers:
            sections.append({"titre": "Dossiers surveillés", "icone": "dossier_photos",
                             "lignes": [[os.path.basename(d) or d, d, "dossier_photos"] for d in dossiers]})
        if releves.get("captures"):
            sections.append({"titre": "Dernières captures lues", "icone": "pogo_capture", "lignes": [
                [c["fichier"], f"{datetime.fromtimestamp(c['quand']).strftime('%d/%m %H:%M')} · {c['trouve']} stat(s)",
                 "pogo_capture"] for c in releves["captures"][:8]]})
        return {"etat": etat, "sections": sections}
