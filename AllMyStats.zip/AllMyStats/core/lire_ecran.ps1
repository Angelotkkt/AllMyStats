﻿# AllMyStats : capture la fenêtre du jeu (si elle est au premier plan) et lit le texte avec l'OCR de Windows.
# La capture est supprimée juste après par AllMyStats.
#
# Ce que le script écrit (une info par ligne) :
#   DEVANT:<programme>|<titre>   la fenêtre qui était au premier plan
#   PROCESSUS:, TITRE:           le jeu reconnu
#   FENETRE:<l>x<h>              la taille de sa fenêtre
#   LUMINOSITE:<moyenne>/<max>   pour repérer une capture toute noire
#   LANGUE:<code>                la langue de lecture de Windows
#   ETAT:<OK|PAS_AU_PREMIER_PLAN|REDUIT|FENETRE_TROP_PETITE|CAPTURE_NOIRE|PAS_DE_LANGUE_OCR|ERREUR ...>
#   TEXTE:                       puis le texte lu, une ligne par ligne de l'écran
# Avec -Fichier, le script lit une image déjà enregistrée (capture d'écran du téléphone) au lieu de l'écran.
# -Motif : expression reconnue dans le NOM du programme ou le TITRE de la fenêtre (ex : « roblox|blox fruits »),
# pour les lanceurs qui renomment la fenêtre (Bloxstrap…) ou les versions du jeu au nom différent.
param([string]$Image, [string]$Processus = "RobloxPlayerBeta", [string]$Fichier = "", [string]$Motif = "")

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
try {
    Add-Type @"
using System; using System.Runtime.InteropServices;
public class AllMyStatsFenetre {
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, System.Text.StringBuilder s, int n);
  public struct RECT { public int Left, Top, Right, Bottom; }
}
"@
    Add-Type -AssemblyName System.Drawing
    if ($Fichier) {
        # Une image déjà enregistrée : on la recopie telle quelle
        $source = [System.Drawing.Image]::FromFile($Fichier)
        $l = $source.Width; $haut = $source.Height
        Write-Output ("FENETRE:" + $l + "x" + $haut)
        $capture = New-Object System.Drawing.Bitmap $l, $haut
        $g = [System.Drawing.Graphics]::FromImage($capture)
        $g.DrawImage($source, 0, 0, $l, $haut)
        $g.Dispose(); $source.Dispose()
    } else {
    [AllMyStatsFenetre]::SetProcessDPIAware() | Out-Null
    $h = [AllMyStatsFenetre]::GetForegroundWindow()
    [uint32]$idp = 0
    [AllMyStatsFenetre]::GetWindowThreadProcessId($h, [ref]$idp) | Out-Null
    $p = Get-Process -Id $idp -ErrorAction SilentlyContinue
    $sb = New-Object System.Text.StringBuilder 512
    [AllMyStatsFenetre]::GetWindowText($h, $sb, 512) | Out-Null
    $titreDevant = $sb.ToString()
    if ($p) { Write-Output ("DEVANT:" + $p.ProcessName + "|" + $titreDevant) } else { Write-Output ("DEVANT:|" + $titreDevant) }
    # Un navigateur ouvert sur une page « Blox Fruits » (wiki…) n'est pas le jeu
    $navigateur = $p -and ($p.ProcessName -match "^(msedge|chrome|firefox|opera|brave|vivaldi|allmystats|explorer)$")
    $reconnu = $p -and (($Processus.Split(",") -contains $p.ProcessName) -or
               ($Motif -and -not $navigateur -and (($p.ProcessName -match $Motif) -or ($titreDevant -match $Motif))))
    if (-not $reconnu) { Write-Output "ETAT:PAS_AU_PREMIER_PLAN"; exit }
    if ([AllMyStatsFenetre]::IsIconic($h)) { Write-Output "ETAT:REDUIT"; exit }
    Write-Output ("PROCESSUS:" + $p.ProcessName)
    Write-Output ("TITRE:" + $titreDevant)
    $r = New-Object AllMyStatsFenetre+RECT
    [AllMyStatsFenetre]::GetWindowRect($h, [ref]$r) | Out-Null
    $l = $r.Right - $r.Left; $haut = $r.Bottom - $r.Top
    Write-Output ("FENETRE:" + $l + "x" + $haut)
    if ($l -lt 300 -or $haut -lt 200) { Write-Output "ETAT:FENETRE_TROP_PETITE"; exit }

    # Capture de la fenêtre
    $capture = New-Object System.Drawing.Bitmap $l, $haut
    $g = [System.Drawing.Graphics]::FromImage($capture)
    $g.CopyFromScreen($r.Left, $r.Top, 0, 0, $capture.Size)
    $g.Dispose()
    }

    # Image toute noire ? (plein écran exclusif : Windows ne laisse pas capturer le jeu)
    $somme = 0; $max = 0; $n = 0
    for ($y = 0; $y -lt 24; $y++) {
        for ($x = 0; $x -lt 32; $x++) {
            $c = $capture.GetPixel([int](($x + 0.5) * $l / 32), [int](($y + 0.5) * $haut / 24))
            $v = [int](($c.R + $c.G + $c.B) / 3); $somme += $v; $n++
            if ($v -gt $max) { $max = $v }
        }
    }
    Write-Output ("LUMINOSITE:" + [int]($somme / $n) + "/" + $max)
    if ($max -lt 12) { $capture.Dispose(); Write-Output "ETAT:CAPTURE_NOIRE"; exit }

    # Moteur de lecture de Windows (Windows.Media.Ocr)
    Add-Type -AssemblyName System.Runtime.WindowsRuntime
    $null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
    $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType = WindowsRuntime]
    $moteur = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
    if (-not $moteur) {
        foreach ($langue in [Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages) {
            $moteur = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($langue)
            if ($moteur) { break }
        }
    }
    if (-not $moteur) { $capture.Dispose(); Write-Output "ETAT:PAS_DE_LANGUE_OCR"; exit }
    Write-Output ("LANGUE:" + $moteur.RecognizerLanguage.LanguageTag)

    # Agrandissement x2 (l'OCR lit mieux les petits textes du jeu), sans dépasser la taille que Windows accepte
    $limite = [Windows.Media.Ocr.OcrEngine]::MaxImageDimension
    if (-not $limite -or $limite -lt 1000) { $limite = 2600 }
    $echelle = [Math]::Min(2.0, ($limite - 1) / [Math]::Max($l, $haut))
    $grande = New-Object System.Drawing.Bitmap ([int]($l * $echelle)), ([int]($haut * $echelle))
    $g = [System.Drawing.Graphics]::FromImage($grande)
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.DrawImage($capture, 0, 0, $grande.Width, $grande.Height)
    $g.Dispose(); $capture.Dispose()
    $grande.Save($Image, [System.Drawing.Imaging.ImageFormat]::Png)
    $grande.Dispose()

    $asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
        $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
        $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
    function Attendre($op, [Type]$type) {
        $t = $asTask.MakeGenericMethod($type).Invoke($null, @($op)); $t.Wait(-1) | Out-Null; $t.Result
    }
    $fichier = Attendre ([Windows.Storage.StorageFile]::GetFileFromPathAsync($Image)) ([Windows.Storage.StorageFile])
    $flux = Attendre ($fichier.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
    $decodeur = Attendre ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($flux)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $bitmap = Attendre ($decodeur.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
    $resultat = Attendre ($moteur.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
    $flux.Dispose()
    Write-Output "ETAT:OK"
    Write-Output "TEXTE:"
    foreach ($ligne in $resultat.Lines) { Write-Output $ligne.Text }
} catch {
    Write-Output ("ETAT:ERREUR " + $_.Exception.Message)
}
