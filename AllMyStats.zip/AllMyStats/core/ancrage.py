"""« Carte collée » : une vraie fenêtre de navigateur (connectée à ton compte, comme sur le site) posée
exactement sur une zone de la fenêtre d'AllMyStats. Le travail Windows est fait par ancrage.ps1, qui reste
lancé en fond tant qu'une carte est affichée et reçoit ses ordres ligne par ligne."""

import os
import queue
import subprocess
import threading

from core.fenetre import _navigateurs_possibles

SCRIPT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ancrage.ps1")
SANS_FENETRE = getattr(subprocess, "CREATE_NO_WINDOW", 0)
_etat = {"proc": None, "file": None, "url": None}
_verrou = threading.Lock()


def _assistant():
    p = _etat["proc"]
    if p and p.poll() is None:
        return p
    p = subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", SCRIPT],
                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                         creationflags=SANS_FENETRE, text=True, encoding="utf-8", errors="replace", bufsize=1)
    file = queue.Queue()

    def lire():
        for ligne in p.stdout:
            file.put(ligne.strip().lstrip("﻿"))
    threading.Thread(target=lire, daemon=True).start()
    _etat.update(proc=p, file=file, url=None)
    return p


def _ordre(ligne, attente=8):
    p = _assistant()
    file = _etat["file"]
    while not file.empty():
        file.get_nowait()
    try:
        p.stdin.write(ligne + "\n")
        p.stdin.flush()
        return file.get(timeout=attente)
    except (OSError, queue.Empty):
        return "DELAI"


def _ligne_placer(zone):
    valeurs = [zone.get(k, 0) for k in ("x", "y", "l", "h", "lv", "hv", "dpr")]
    return "PLACER " + " ".join(f"{float(v):.3f}" for v in valeurs)


def montrer(url, profil, zone):
    """Affiche (ou ouvre) la carte collée sur la zone donnée. Renvoie {"ok": bool, "raison": texte}."""
    if os.name != "nt":
        return {"ok": False, "raison": "La carte collée ne marche que sur Windows."}
    with _verrou:
        if _etat["url"] == url and _ordre("EXISTE") == "True":
            _ordre(_ligne_placer(zone))
            _ordre("MONTRER")
            _ordre(_ligne_placer(zone))   # une fois visible, la mesure est la plus juste
            return {"ok": True}
        if _etat["url"]:
            _ordre("FERMER")
            _etat["url"] = None
        if _ordre("AMS") != "OK":
            return {"ok": False, "raison": "Clique dans la fenêtre d'AllMyStats puis réessaie."}
        _ordre("PHOTO")
        exe = next((e for e in _navigateurs_possibles() if os.path.isfile(e)), None)
        if not exe:
            return {"ok": False, "raison": "Il faut Microsoft Edge ou Google Chrome."}
        subprocess.Popen([exe, f"--app={url}", f"--user-data-dir={profil}", "--window-size=1200,800",
                          "--no-first-run", "--no-default-browser-check"], creationflags=SANS_FENETRE)
        if _ordre("TROUVER 15000", attente=20) != "OK":
            return {"ok": False, "raison": "La fenêtre de la carte n'a pas été trouvée."}
        _etat["url"] = url
        _ordre(_ligne_placer(zone))
        _ordre("MONTRER")
        _ordre(_ligne_placer(zone))   # après le premier placement, la page a sa vraie taille : on remesure
        return {"ok": True}


def placer(zone):
    with _verrou:
        if _etat["url"]:
            _ordre(_ligne_placer(zone))
    return {"ok": True}


def cacher():
    with _verrou:
        if _etat["url"] and _etat["proc"] and _etat["proc"].poll() is None:
            _ordre("CACHER")
    return {"ok": True}
