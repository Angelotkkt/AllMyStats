﻿# AllMyStats : « carte collée ». Garde une fenêtre (la carte interactive, connectée à ton compte) posée exactement
# sur une zone de la fenêtre d'AllMyStats : elle la suit quand tu la déplaces, et seule sa page est visible.
# Commandes reçues ligne par ligne (une réponse par commande) :
#   AMS                 la fenêtre au premier plan est celle d'AllMyStats : on la retient
#   PHOTO               liste les fenêtres déjà ouvertes (pour reconnaître ensuite la nouvelle)
#   TROUVER <ms>        attend la nouvelle fenêtre de la carte
#   PLACER x y l h lv hv dpr   zone à couvrir (pixels CSS de la page) + taille de la page + zoom de l'écran
#   MONTRER / CACHER / EXISTE / FERMER
$ErrorActionPreference = "Stop"
Add-Type -TypeDefinition @"
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

public static class AmsAncre {
    public struct RECT { public int L, T, R, B; }
    delegate bool EnumProc(IntPtr h, IntPtr p);
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] static extern bool IsWindow(IntPtr h);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr apres, int x, int y, int cx, int cy, uint f);
    [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int n);
    [DllImport("gdi32.dll")] static extern IntPtr CreateRectRgn(int a, int b, int c, int d);
    [DllImport("user32.dll")] static extern int SetWindowRgn(IntPtr h, IntPtr rgn, bool redessiner);
    [DllImport("user32.dll")] static extern int GetWindowRgnBox(IntPtr h, out RECT r);
    [DllImport("user32.dll", EntryPoint = "SetWindowLongPtrW")] static extern IntPtr SetWindowLongPtr(IntPtr h, int i, IntPtr v);
    [DllImport("user32.dll", EntryPoint = "GetWindowLongPtrW")] static extern IntPtr GetWindowLongPtr(IntPtr h, int i);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr p);
    [DllImport("user32.dll")] static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
    public struct POINT { public int X, Y; }
    [DllImport("user32.dll")] static extern bool ClientToScreen(IntPtr h, ref POINT p);
    [DllImport("user32.dll")] static extern bool GetClientRect(IntPtr h, out RECT r);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder s, int n);
    [DllImport("user32.dll")] static extern int GetWindowTextLength(IntPtr h);
    [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr h, uint cmd);
    [DllImport("user32.dll")] static extern bool PostMessage(IntPtr h, uint m, IntPtr w, IntPtr l);

    [DllImport("user32.dll")] static extern bool SetProcessDpiAwarenessContext(IntPtr contexte);
    [DllImport("user32.dll")] static extern bool SetProcessDPIAware();

    // Indispensable avec un zoom Windows (125 %, 150 %…) : sinon Windows donne des positions « mises à
    // l'échelle » à ce programme, et la carte est mal placée et mal dimensionnée.
    public static string ActiverZoom() {
        try { if (SetProcessDpiAwarenessContext(new IntPtr(-4))) return "PAR_ECRAN"; } catch { }   // chaque écran son zoom
        try { if (SetProcessDPIAware()) return "SYSTEME"; } catch { }
        return "AUCUN";
    }

    public static IntPtr Ams = IntPtr.Zero, Carte = IntPtr.Zero;
    static HashSet<IntPtr> photo = new HashSet<IntPtr>();
    static readonly object verrou = new object();
    static int ox, oy, cl, ch;
    static RECT zone, dernier;
    static bool visible = false, place = false;

    static string Classe(IntPtr h) { var s = new StringBuilder(256); GetClassName(h, s, 256); return s.ToString(); }

    static List<IntPtr> Fenetres() {
        var liste = new List<IntPtr>();
        EnumWindows((h, p) => {
            if (IsWindowVisible(h) && Classe(h) == "Chrome_WidgetWin_1" && GetWindowTextLength(h) > 0
                && GetWindow(h, 4) == IntPtr.Zero) liste.Add(h);
            return true;
        }, IntPtr.Zero);
        return liste;
    }

    // Le rectangle exact de la PAGE d'une fenêtre (sans barre de titre ni bordures), en pixels de l'écran
    static bool Vue(IntPtr fenetre, out RECT vue) {
        RECT meilleur = new RECT();
        long aire = 0;
        EnumChildWindows(fenetre, (h, p) => {
            if (Classe(h) == "Chrome_RenderWidgetHostHWND") {
                RECT r;
                if (GetWindowRect(h, out r)) {
                    long s = (long)(r.R - r.L) * (r.B - r.T);
                    if (s > aire) { aire = s; meilleur = r; }
                }
            }
            return true;
        }, IntPtr.Zero);
        vue = meilleur;
        return aire > 0;
    }

    public static string ChoisirAms() {
        IntPtr h = GetForegroundWindow();
        if (Classe(h) != "Chrome_WidgetWin_1") return "ECHEC";
        Ams = h; return "OK";
    }

    public static string Photo() { photo = new HashSet<IntPtr>(Fenetres()); return "OK"; }

    public static string Trouver(int ms) {
        DateTime fin = DateTime.Now.AddMilliseconds(ms);
        while (DateTime.Now < fin) {
            foreach (IntPtr h in Fenetres()) {
                if (h != Ams && !photo.Contains(h)) {
                    Carte = h;
                    SetWindowLongPtr(Carte, -8, Ams);                       // la carte « appartient » à AllMyStats
                    long ex = (long)GetWindowLongPtr(Carte, -20);
                    SetWindowLongPtr(Carte, -20, (IntPtr)(ex & ~0x40000L));  // pas de bouton dans la barre des tâches
                    return "OK " + Carte.ToInt64();
                }
            }
            Thread.Sleep(100);
        }
        return "ECHEC";
    }

    public static string Placer(double x, double y, double l, double h, double lv, double hv, double dpr) {
        RECT a, m, va, vm;
        if (!GetWindowRect(Ams, out a) || !GetWindowRect(Carte, out m)) return "ECHEC";
        int lz = (int)Math.Round(l * dpr), hz = (int)Math.Round(h * dpr);
        int cibleX, cibleY, mx, extraL;   // cible = coin du cadre (par rapport à la fenêtre d'AllMyStats)
        string mode = "OK";
        POINT pa = new POINT(), pm = new POINT();
        RECT ca, cm;
        if (ClientToScreen(Ams, ref pa) && GetClientRect(Ams, out ca) && ClientToScreen(Carte, ref pm) && GetClientRect(Carte, out cm)
            && ca.R > 0 && cm.R > 0) {
            int barre = Math.Max(0, ca.B - (int)Math.Round(hv * dpr));
            if (barre <= 3) barre = 0;
            cibleX = pa.X + (int)Math.Round(x * dpr) - a.L; cibleY = pa.Y + barre + (int)Math.Round(y * dpr) - a.T;
            mx = pm.X - m.L; extraL = (m.R - m.L) - cm.R;
        } else if (Vue(Ams, out va) && Vue(Carte, out vm)) {
            cibleX = va.L + (int)Math.Round(x * dpr) - a.L; cibleY = va.T + (int)Math.Round(y * dpr) - a.T;
            mx = vm.L - m.L; extraL = (m.R - m.L) - (vm.R - vm.L);
        } else {
            int W = a.R - a.L, H = a.B - a.T;
            int bord = Math.Max(0, (int)Math.Round((W - lv * dpr) / 2.0));
            int haut = Math.Max(0, (int)Math.Round(H - hv * dpr) - bord);
            cibleX = bord + (int)Math.Round(x * dpr); cibleY = haut + (int)Math.Round(y * dpr);
            mx = bord; extraL = 2 * bord;
            mode = "ESTIME";
        }
        lock (verrou) {
            // Toute la fenêtre de la carte (sa barre de titre comprise) tient DANS le cadre : rien ne déborde
            // sur les boutons d'AllMyStats au-dessus.
            ox = cibleX - mx; oy = cibleY;
            cl = lz + extraL; ch = hz + Math.Max(0, extraL / 2);
            zone = new RECT { L = mx, T = 0, R = mx + lz, B = hz };
            dernier = new RECT();
            place = true;
            Appliquer(true);
        }
        return mode;
    }

    static void Appliquer(bool forcer) {
        RECT a;
        if (!GetWindowRect(Ams, out a)) return;
        if (forcer || a.L != dernier.L || a.T != dernier.T || a.R != dernier.R || a.B != dernier.B) {
            dernier = a;
            SetWindowPos(Carte, IntPtr.Zero, a.L + ox, a.T + oy, cl, ch, 0x0004 | 0x0010);   // sans changer l'ordre ni le focus
            forcer = true;
        }
        // Seule la page doit être visible. Edge efface cette découpe quand il redessine sa fenêtre :
        // on vérifie à chaque tour et on la remet aussitôt si elle a disparu ou changé.
        RECT r;
        int type = GetWindowRgnBox(Carte, out r);
        bool bonne = type != 0 && r.L == zone.L && r.T == zone.T && r.R == zone.R && r.B == zone.B;
        if (forcer || !bonne) SetWindowRgn(Carte, CreateRectRgn(zone.L, zone.T, zone.R, zone.B), true);
    }

    public static string Montrer() { visible = true; if (Existe()) ShowWindow(Carte, 4); return "OK"; }
    public static string Cacher() { visible = false; if (Existe()) ShowWindow(Carte, 0); return "OK"; }
    public static bool Existe() { return Carte != IntPtr.Zero && IsWindow(Carte); }
    // Ferme une carte laissée par une ancienne version d'AllMyStats (avant une mise à jour)
    public static string FermerAncienne(long h) {
        IntPtr p = new IntPtr(h);
        if (p != Carte && IsWindow(p) && Classe(p) == "Chrome_WidgetWin_1") PostMessage(p, 0x0010, IntPtr.Zero, IntPtr.Zero);
        return "OK";
    }
    public static string Fermer() {
        if (Existe()) PostMessage(Carte, 0x0010, IntPtr.Zero, IntPtr.Zero);
        Carte = IntPtr.Zero; place = false; visible = false; return "OK";
    }

    public static void Suivre() {
        var t = new Thread(() => {
            while (true) {
                try {
                    if (Ams != IntPtr.Zero && !IsWindow(Ams)) { Fermer(); Environment.Exit(0); }
                    if (place && visible && Existe() && !IsIconic(Ams)) lock (verrou) { Appliquer(false); }
                } catch { }
                Thread.Sleep(15);
            }
        });
        t.IsBackground = true;
        t.Start();
    }
}
"@
[AmsAncre]::ActiverZoom() | Out-Null
[AmsAncre]::Suivre()
$c = [Globalization.CultureInfo]::InvariantCulture
while ($true) {
    $ligne = [Console]::In.ReadLine()
    if ($ligne -eq $null) { [AmsAncre]::Fermer() | Out-Null; break }
    $p = $ligne.Trim().Split(" ")
    try {
        switch ($p[0]) {
            "AMS"     { $r = [AmsAncre]::ChoisirAms() }
            "PHOTO"   { $r = [AmsAncre]::Photo() }
            "TROUVER" { $r = [AmsAncre]::Trouver([int]$p[1]) }
            "PLACER"  { $r = [AmsAncre]::Placer([double]::Parse($p[1], $c), [double]::Parse($p[2], $c), [double]::Parse($p[3], $c),
                          [double]::Parse($p[4], $c), [double]::Parse($p[5], $c), [double]::Parse($p[6], $c), [double]::Parse($p[7], $c)) }
            "MONTRER" { $r = [AmsAncre]::Montrer() }
            "CACHER"  { $r = [AmsAncre]::Cacher() }
            "EXISTE"  { $r = [string][AmsAncre]::Existe() }
            "FERMER"  { $r = [AmsAncre]::Fermer() }
            "ANCIENNE" { $r = [AmsAncre]::FermerAncienne([long]$p[1]) }
            default   { $r = "INCONNU" }
        }
    } catch { $r = "ERREUR " + $_.Exception.Message }
    [Console]::Out.WriteLine($r)
    [Console]::Out.Flush()
}
