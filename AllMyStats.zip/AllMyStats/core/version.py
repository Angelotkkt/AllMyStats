"""Version de AllMyStats. À augmenter à chaque nouvelle version."""

VERSION = "2.10.0"

# Dépôt GitHub public où sont publiées les mises à jour (« pseudo/AllMyStats »). Vide = pas encore créé :
# on peut aussi le donner dans Paramètres > Mises à jour.
DEPOT_MAJ = "Angelotkkt/AllMyStats"

NOUVEAUTES = [
    "Interactive Map : la carte officielle s'affiche dans AllMyStats avec ton compte HoYoLAB, comme sur le site (essai)",
    "Interactive Map : bouton « Carte avec mon compte » pour cocher tes trouvailles (connexion HoYoLAB)",
    "Interactive Map : bouton « Se connecter à HoYoLAB » sans passer en plein écran, et « Dans mon navigateur »",
    "Interactive Map : la carte s'affiche directement dans AllMyStats, avec des onglets pour changer de carte",
    "Genshin : ton pseudo s'affiche à la place de l'UID",
    "Genshin : les nouveaux persos ont leur nom et leur portrait, les armes de tes vœux ont leur image",
    "Genshin : nouvelle sous-catégorie Interactive Map (la carte officielle de Teyvat, toujours à jour)",
    "Valorant passe par HenrikDev (comme les trackers) : rang, RR et parties même jeu fermé",
    "Valorant : nouvelle fenêtre « Se connecter avec Riot », puis tout est automatique même jeu fermé",
    "Valorant : la bonne région et la bonne version du jeu sont trouvées toutes seules",
    "Connexion à Internet plus solide : un proxy Windows qui ne marche plus est contourné",
    "Les erreurs de connexion affichent leur vraie raison",
    "Valorant : connexion au client Riot plus solide (proxy, sécurité) et message d'erreur précis",
    "Réparé : l'erreur « Failed to import encodings module » au redémarrage après une mise à jour",
    "Nouveau jeu : Valorant, tout automatique comme un tracker (rang, RR, K/D, ACS, headshots, parties, agents, cartes)",
    "Paramètres > Jeux affichés : masque les jeux auxquels tu ne joues pas",
    "Nouveau jeu : Pokémon GO (niveau, PX, distance, Pokémon attrapés, PokéStops)",
    "Pokémon GO : tes captures du profil sont lues toutes seules dès qu'elles arrivent sur ton PC (OneDrive)",
    "Glisse des captures d'écran dans AllMyStats pour les faire lire",
    "Les nouvelles versions sont trouvées tout de suite après leur publication",
    "La barre de gauche affiche le pseudo de chaque compte connecté, même quand tu es sur un autre jeu",
    "Mises à jour automatiques par Internet : plus besoin de télécharger de fichier",
    "Nouveau bouton « Tester la lecture d'écran » : AllMyStats te dit exactement ce qui bloque",
    "Lecture d'écran plus solide : images trop grandes, langue de Windows, capture noire repérée",
    "Blox Fruits est lu même quand les journaux de Roblox sont introuvables",
    "Call of Duty reconnu même si son programme a un nom inconnu",
    "Connexion Activision plus solide (plus d'erreur inattendue)",
    "Connexion Activision réparée : la fenêtre ouvre callofduty.com, clique sur CONNEXION",
    "Nouvelle catégorie Call of Duty : BO6, BO7, Cold War, MW4, Warzone, Warzone MW4, MW3 et MW2",
    "Ton Combat Record est lu tout seul à l'écran et rangé dans le bon jeu",
    "Connexion Activision pour les stats officielles de Cold War et MW2",
    "Les jeux d'une même série sont rangés dans un dossier dans la barre de gauche",
]


def en_tuple(texte):
    try:
        return tuple(int(x) for x in str(texte).strip().split("."))
    except ValueError:
        return (0,)
