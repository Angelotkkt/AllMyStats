"""Prépare une mise à jour à publier sur le dépôt GitHub des mises à jour.

    python outils/preparer_publication.py <dossier_du_depot>

Écrit dans ce dossier : AllMyStats.zip (le code) et maj.json (version, nouveautés, empreinte sha256).
Il reste à faire « git add / commit / push » dans le dépôt : AllMyStats le verra dans les 6 heures.
"""

import hashlib
import json
import os
import re
import shutil
import sys
import zipfile

RACINE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main(destination):
    texte = open(os.path.join(RACINE, "core", "version.py"), encoding="utf-8").read()
    version = re.search(r'VERSION\s*=\s*"([\d.]+)"', texte).group(1)
    nouveautes = re.findall(r'^\s*"([^"]+)",\s*$', texte.split("NOUVEAUTES", 1)[1].split("]", 1)[0], re.M)
    os.makedirs(destination, exist_ok=True)
    chemin_zip = os.path.join(destination, "AllMyStats.zip")
    with zipfile.ZipFile(chemin_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for dossier, sous, fichiers in os.walk(RACINE):
            sous[:] = [d for d in sous if d not in ("__pycache__", "data", "build", "dist", ".git", ".github", "android",
                                                    "publication", ".gradle")]
            for f in fichiers:
                if f.endswith((".pyc", ".zip")):
                    continue
                complet = os.path.join(dossier, f)
                z.write(complet, os.path.join("AllMyStats", os.path.relpath(complet, RACINE)))
    empreinte = hashlib.sha256(open(chemin_zip, "rb").read()).hexdigest()
    with open(os.path.join(destination, "maj.json"), "w", encoding="utf-8") as f:
        json.dump({"version": version, "nouveautes": nouveautes, "fichier": "AllMyStats.zip", "sha256": empreinte},
                  f, ensure_ascii=False, indent=2)
    # Le site de téléchargement (GitHub Pages) : la page + les emojis et le logo de l'appli
    for source, nom in ((os.path.join(RACINE, "site", "index.html"), "index.html"),
                        (os.path.join(RACINE, "web", "icones.js"), "icones.js"),
                        (os.path.join(RACINE, "web", "icone.png"), "icone.png")):
        if os.path.exists(source):
            shutil.copyfile(source, os.path.join(destination, nom))
    # L'appli Android et sa fabrication automatique par GitHub (voir .github/workflows/android.yml)
    for dossier in ("android", ".github"):
        source = os.path.join(RACINE, dossier)
        if os.path.isdir(source):
            cible = os.path.join(destination, dossier)
            shutil.rmtree(cible, ignore_errors=True)
            shutil.copytree(source, cible, ignore=shutil.ignore_patterns("build", ".gradle", "cle.jks", "*.apk"))
    print(f"AllMyStats {version} prêt dans {destination}")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else os.path.join(RACINE, "publication"))
